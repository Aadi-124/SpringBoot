package com.springdb.DataBaseApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataBaseAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataBaseAppApplication.class, args);
	}

}
